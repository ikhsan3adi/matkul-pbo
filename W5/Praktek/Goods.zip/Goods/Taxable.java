public interface Taxable {
  public float taxRate = 0.06f;

  public float calculateTax();
}
